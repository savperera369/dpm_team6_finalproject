# import math
# import time
# from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor
# 
# CM = Motor("B")
# KM = Motor("C")
# 
# KM.set_power(0)
# CM.set_power(0)