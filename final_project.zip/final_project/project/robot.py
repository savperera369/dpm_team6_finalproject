print("Beginning startup...")

import time
import math
from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor, EV3GyroSensor

# GLOBAL VARIABLES

enabled = True
job_list = {(0,0,"A"),(0,0,"A"),(0,0,"A")}
RED = (43.5, 9.3, 7.6)
GREEN = (5.0, 19.7, 10.5)
BLUE = (14.8, 11.9, 15.3)
BROWN = (45.9, 30.1, 20.7)
RED_ERROR = 7
GREEN_ERROR = 5
BLUE_ERROR = 8
BROWN_ERROR = 10
position = [0, 0, 0]
initial_rotation = 0

# INITIALIZE SENSORS AND MOTORS
print("Initializing sensors and motors...")
LM = Motor("D")
RM = Motor("C")
CS1 = EV3ColorSensor(1)
CS2 = EV3ColorSensor(2)
GS = EV3GyroSensor(4)
wait_ready_sensors()
print("Sensors and motors initialized.")

# NAVIGATION FUNCTIONS

def color_distance(raw_value1, raw_value2):
    dR = raw_value1[0] - raw_value2[0]
    dG = raw_value1[1] - raw_value2[1]
    dB = raw_value1[2] - raw_value2[2]
    return math.sqrt((dR**2)+(dG**2)+(dB**2))

# Returns NONE if black, between colors, or not sure
def color(sensor_name):
    raw_value = sensor_name.get_raw_value()
    if color_distance(raw_value, RED) <= RED_ERROR:
        return "RED"
    elif color_distance(raw_value, GREEN) <= GREEN_ERROR:
        return "GREEN"
    elif color_distance(raw_value, BLUE) <= BLUE_ERROR:
        return "BLUE"
    elif color_distance(raw_value,BROWN) <= BROWN_ERROR:
        return "BROWN"
    else:
        return "NONE"

def stop():
    LM.set_power(0)
    RM.set_power(0)

# d = direction (0 left, 1 right), p = power, t = time
def rotate(d, p, t):
    LM.set_power(((-1)**(d + 1)) * p)
    RM.set_power(((-1)**(2 - d)) * p)
    time.sleep(t)
    stop()
    
# d = direction (0 forwards, 1 backwards), p = power, t = time (0 = indefinite)
def straight(d, p, t):
    initial_time = time.time()
    while (((time.time() - initial_time) < t) or (not t)):
        LM.set_power(((-1)**(2 - d)) * p)
        RM.set_power(((-1)**(2 - d)) * p)
        if (not t):
            return
    stop()

def forward():
    UPDATE_DELAY = 0.1
    DRIVE_PWR = 20
    ROTATION_PWR = 10
    ROTATION_TIME = 0.1
    t = 0
    straight(0, 20, 1)
    while (color(CS1) != "GREEN") and (color (CS2) != "GREEN"): #color(CS1) != "GREEN") and (color (CS2) != "GREEN"
        #t = time.time() - t # debug
        #print(t, " ", color(CS1), " ", color(CS2)) # debug
        straight(0, DRIVE_PWR, 0)
        time.sleep(UPDATE_DELAY)
        # If going left or right, i.e., tracing blue lines
        if (position[2] == 0) or (position[2] == 2):
            if (color(CS1) == "BLUE"):
                stop()
                rotate(0, ROTATION_PWR, ROTATION_TIME)
            if (color(CS2) == "BLUE"):
                stop()
                rotate(1, ROTATION_PWR, ROTATION_TIME)
        # If going up or down, i.e., tracing red lines
        if (position[2] == 1) or (position[2] == 3):
            if (color(CS1) == "RED"):
                rotate(0, ROTATION_PWR, ROTATION_TIME)
            if (color(CS2) == "RED"):
                rotate(1, ROTATION_PWR, ROTATION_TIME)

    stop()

# Sensor drifts: right turns are too big, left turns are too small
def turn_left():
    straight(0, 20, 0.4)
    POWER = 20
    DURATION = 0.01
    WINDOW = 2.5
    target = ((position[2] + 1) % 4)*90
    rotation = (GS.get_abs_measure() - initial_rotation) % 360
    while (abs(target - rotation) > WINDOW):
        rotation = (GS.get_abs_measure() - initial_rotation) % 360
        rotate(0, POWER, DURATION)
    position[2] = (position[2] + 1) % 4
    straight(0, 20, 0.6)
    
def turn_right():
    straight(0, 20, 0.4)
    POWER = 20
    DURATION = 0.01
    WINDOW = 2.5
    target = ((position[2] - 1) % 4)*90
    rotation = (GS.get_abs_measure() - initial_rotation) % 360
    while (abs(target - rotation) > WINDOW):
        rotation = (GS.get_abs_measure() - initial_rotation) % 360
        rotate(1, POWER, DURATION)
    position[2] = (position[2] - 1) % 4
    straight(0, 20, 0.6)

def spin_carousel():
    pass

# MAIN PROGRAM
initial_rotation = GS.get_abs_measure() # don't delete
while True:
    forward()
    turn_left()