#thisfilewaswrittenbykALE

#TODO: make a function to check current position (after moving there) and deploy block as necessary
#TODO: add a delimeter to the end of instructions to indicate return to origin
#TODO: make the turning better - change the behavior of the color sensors??????
#TODO: update docs to reflect additions to code

from robot import turn_left
from robot import turn_right
from robot import forward
from robot import turn_180
from inputAlgo import createPath
from test_file_carousel_v2 import spin_carousel
from robot import straight
from STOP import stop
from robot import color

from pathfinding import *
import time
import math
from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor, EV3GyroSensor

d = 0

# LM = Motor("D")
# RM = Motor("C")
# temp = createPath()
# inputVar = temp
# print(inputVar)

# def turn_right():
#     pass
# 
# def turn_left():
#     pass
# 
# def forward():
#     pass

# inputVar = [(0,0),(1,0),(2,0),(1,0),(0,0)]

(inputVar, jobsArr) = createPath()
print(inputVar)

def isFire(pathArray, index, jobsArray):
    print("looking for fire")
    print(jobsArray)
    for job in jobsArray:
        print(job)
        (x_c,y_c,fireType) = job
        if int(x_c) == pathArray[index][0] and int(y_c) == pathArray[index][1]:
            print("found a fire!")
            #deploy_suppressant(fireType)
            return fireType
        
#     pass

# def deploy_suppressant(fireType):
#     LM.set_power(-25)
#     RM.set_power(-25)
#     time.sleep(1)
#     LM.set_power(0)
#     RM.set_power(0)
#     spin_carousel(fireType)
#     LM.set_power(25)
#     RM.set_power(25)
#     time.sleep(.5)
#     LM.set_power(0)
#     RM.set_power(0)
#     stop()


def path_to_instruction(inputVar,d):
    for i in range(len(inputVar)-1):
        print("entering loop")
            
        if inputVar[i][0] < inputVar[i+1][0] and inputVar[i][1] == inputVar[i+1][1] and d == 0: #travel in +x direction, already facing +x direction
            forward()
            d = 0
            print("+x from +x")
            print("moving forward")
#             isFire(inputVar, i+1, jobsArr)
#             if i==(len(inputVar)-1):
#                 stop()
        elif inputVar[i][0] < inputVar[i+1][0] and inputVar[i][1] == inputVar[i+1][1] and d != 0: #travel in +x direction, not already facing +x direction
            if d == 1:
                turn_right()
                forward()
                d = 0
                print("+x from +y")
                print("turning right")
                print("moving foward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            elif d == 2:
                turn_180(isFire(inputVar, i, jobsArr))
                forward() 
                d = 0
                print("+x from -x")
                print("turning 180")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            elif d == 3:
                turn_left()
                forward()
                d = 0
                print("+x from -y")
                print("turning left")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
        elif inputVar[i][0] == inputVar[i+1][0] and inputVar[i][1] < inputVar[i+1][1] and d == 1: #travel in +y direction, already facing +y direction
            forward()
            d = 1
            print("+y from +y")
            print("moving forward")
#             isFire(inputVar, i+1, jobsArr)
#             if i==(len(inputVar)-1):
#                 stop()
        elif inputVar[i][0] == inputVar[i+1][0] and inputVar[i][1] < inputVar[i+1][1] and d != 1: #travel in +y direction, not already facing +y direction
            if d == 0:
                turn_left()
                forward()
                d = 1
                print("+y from +x")
                print("turning left")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            elif d == 2:
                turn_right()
                forward()
                d = 1
                print("+y from -x")
                print("turning right")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            elif d == 3:
                turn_180(isFire(inputVar, i, jobsArr))
                forward()
                d = 1
                print("+y from -y")
                print("turning 180")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
        elif inputVar[i][0] > inputVar[i+1][0] and inputVar[i][1] == inputVar[i+1][1] and d == 2: #travel in -x direction, already facing -x direction
            forward()
            d = 2
            print("-x from -x")
            print("moving forward")
#             isFire(inputVar, i+1, jobsArr)
#             if i==(len(inputVar)-1):
#                 stop()
        elif inputVar[i][0] > inputVar[i+1][0] and inputVar[i][1] == inputVar[i+1][1] and d != 2: #travel in -x direction, not already facing -x direction
            if d == 0:
                turn_180(isFire(inputVar, i, jobsArr))
                forward() 
                d = 2
                print("-x from +x")
                print("turning 180")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            if d == 1:
                turn_left()
                forward()
                d = 2
                print("-x from +y")
                print("turning left")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            if d == 3:
                turn_right()
                forward()
                d = 2
                print("-x from -y")
                print("turning right")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
        elif inputVar[i][0] == inputVar[i+1][0] and inputVar[i][1] > inputVar[i+1][1] and d == 3: #travel in -y direciton, already facing -y direction
            forward()
            d = 3
            print("-y from -y")
            print("moving forward")
#             isFire(inputVar, i+1, jobsArr)
#             if i==(len(inputVar)-1):
#                 stop()
        elif inputVar[i][0] == inputVar[i+1][0] and inputVar[i][1] > inputVar[i+1][1] and d != 3: #travel in -y direciton, not already facing -y direction
            if d == 0:
                turn_right()
                forward()
                d = 3
                print("-y from +x")
                print("turning right")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            elif d == 1: 
                turn_180(isFire(inputVar, i, jobsArr))
                forward()
                d = 3
                print("-y from +y")
                print("turning 180")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
            elif d== 2:
                turn_left()
                forward()
                d = 3
                print("-y from -x")
                print("turning left")
                print("moving forward")
#                 isFire(inputVar, i+1, jobsArr)
#                 if i==(len(inputVar)-1):
#                     stop()
        

# pos1=(1,1)
# targ1=(1,1)
# # 
#deploy_suppressant(pos1,targ1,'A')
path_to_instruction(inputVar,d)

