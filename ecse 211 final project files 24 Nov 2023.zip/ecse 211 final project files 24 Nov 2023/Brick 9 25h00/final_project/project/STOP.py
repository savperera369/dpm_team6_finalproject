import time
import math
from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor

RM = Motor("C")
LM = Motor("D")
def stop():
    LM.set_power(0)
    RM.set_power(0)

stop()