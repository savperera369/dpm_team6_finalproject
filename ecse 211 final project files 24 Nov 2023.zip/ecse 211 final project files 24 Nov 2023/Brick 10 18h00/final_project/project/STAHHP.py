from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor, EV3GyroSensor

CM = Motor("A")
KM = Motor("B")
RM = Motor("C")
LM = Motor("D")

LM.set_power(0)
RM.set_power(0)