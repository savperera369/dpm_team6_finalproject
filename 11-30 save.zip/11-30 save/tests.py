from robot import *
from test_file_carousel_v2 import *
from path_to_instructions import *

#hopper test was sone by dropping blocks through the hopper. No script required.

#test for knocker. Runs knocker indefinitely.
def test_knocker():
    while True: 
        knock()
        time.sleep(1)
    
#test for carousel. Spins carousel to all block positions indefinitely.
def test_carousel():
    while True:
        CM.set_power(0)
        time.sleep(1)
        spin_carousel("D")
        time.sleep(0.5)
        spin_carousel("B")
        time.sleep(0.5)
        spin_carousel("C")
        time.sleep(0.5)
        spin_carousel("D")
        time.sleep(0.5)
        spin_carousel("E")
        time.sleep(0.5)
        spin_carousel("F")
        time.sleep(0.5)

#sensor array test. Prints the analyzed and human-readable color sensors data
def test_sensor_array():
    while True:
        print(color(CS1))
        print(color(CS2))
        time.sleep(1)
        
#drivetrain test. Individually tests each drivetrain function indefinitely.
#180 places a block due to system interconnections. Not a consideration for the test
def test_drivetrain():
    while True:
        forward()
        turn_right()
        
        forward()
        turn_left()
        
        forward()
        turn_180("A")

#battery and brickpi tests were conducted using the above component tests.
        
#distribution subsystem test. indefinitely uses knocker, carousel, and hopper to test interconnection of components
def test_distribution_subsystem():
    while True:
        test_carousel()

#navigation subsystem test. goes through a few pre-created paths and ensures robot behaves as expected. User types in path
# def test_navigation_subsystem():
#     path1 = [(0, 0), (1, 0), (1, 1), (1, 0), (2, 0), (2, 1), (2, 2), (2, 1), (3, 1), (3, 2), (3, 3), (3, 2), (3, 1), (2, 1), (2, 0), (1, 0), (0, 0)]#(1,1),(2,2),(3,3)
#     path2 = [(0, 0), (1, 0), (2, 0), (3, 0), (3, 1), (3, 0), (2, 0), (2, 1), (2, 2), (3, 2), (2, 2), (2, 3), (3, 3), (2, 3), (1, 3), (0, 3), (0, 2), (0, 1), (0, 0)]#(3,1),(3,2),(3,3)
#     path3 = [(0, 0), (1, 0), (1, 1), (1, 0), (0, 0), (0, 1), (0, 2), (1, 2), (0, 2), (0, 3), (1, 3), (0, 3), (0, 2), (0, 1), (0, 0)]#(1,1),(1,2),(1,3)
#     
#     fires1 = [(1,1),(2,2),(3,3)]
#     fires2 = [(3,1),(3,2),(3,3)]
#     fres3 = [(1,1),(1,2),(1,3)]
#     
#     (inputVar, jobsArr) = createPath()
#     path_to_instruction(inputVar,0)

