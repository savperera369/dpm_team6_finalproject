print("Beginning startup...")

import time
import math
from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor, EV3GyroSensor

# GLOBAL VARIABLES

enabled = True
job_list = {(0,0,"A"),(0,0,"A"),(0,0,"A")}
RED = (43.5, 9.3, 7.6)
GREEN = (5.0, 19.7, 10.5)
BLUE = (14.8, 11.9, 15.3)
BROWN = (45.9, 30.1, 20.7)
RED_ERROR = 7
GREEN_ERROR = 5
BLUE_ERROR = 8
BROWN_ERROR = 10
position = (0, 0, 0)

# INITIALIZE SENSORS AND MOTORS
print("Initializing sensors and motors...")
LM = Motor("D")
RM = Motor("C")
CS1 = EV3ColorSensor(1)
CS2 = EV3ColorSensor(2)
wait_ready_sensors()
print("Sensors and motors initialized.")

# NAVIGATION FUNCTIONS

def color_distance(raw_value1, raw_value2):
    dR = raw_value1[0] - raw_value2[0]
    dG = raw_value1[1] - raw_value2[1]
    dB = raw_value1[2] - raw_value2[2]
    return math.sqrt((dR**2)+(dG**2)+(dB**2))

# Returns NONE if: (1) black, (2) between colors, (3) not sure
def color(sensor_name):
    raw_value = sensor_name.get_raw_value()
    if color_distance(raw_value, RED) <= RED_ERROR:
        return "RED"
    elif color_distance(raw_value, GREEN) <= GREEN_ERROR:
        return "GREEN"
    elif color_distance(raw_value, BLUE) <= BLUE_ERROR:
        return "BLUE"
    elif color_distance(raw_value,BROWN) <= BROWN_ERROR:
        return "BROWN"
    else:
        return "NONE"

def stop():
    LM.set_power(0)
    RM.set_power(0)

def rotate(d, t): # d = direction 0 left 1 right, t = time in seconds
    POWER = 25
    LM.set_power(((-1)**(d + 1))*POWER)
    RM.set_power(((-1)**(2 - d))* POWER)
    time.sleep(t)
    stop()
    
def straight(d, t): # direction 0 forward 1 reverse, t = time in seconds
    POWER = 25
    L_ADJUST = 0
    R_ADJUST = 0
    #initial_angle = GS.get_dps_measure()
    #SKEW_FACTOR = 0.1     # How much to adjust skew when crossing line
    # How skewed power distribution is towards left motor
    # 50 = balanced, 100 = all left motor, 0 = all right motor
    #skew = 50
    if (position[2] == 0) or (position[2] == 2):
        line_color = "BLUE"
    if (position[2] == 1) or (position[2] == 3):
        line_color = "RED"
    initial_time = time.time()
    while (time.time() - initial_time) < t:
        LM.set_power(((-1)**(2 - d))*(POWER + L_ADJUST))
        RM.set_power(((-1)**(2 - d))*(POWER + R_ADJUST))
    stop()
        #LM.set_power(POWER * (skew / 100))
        #RM.set_power(POWER * ((100 - skew) / 100))
        # If left sensor crosses line, skew right
        #if (color(CS1) == line_color) and (skew > 0):
            #skew = skew - SKEW_FACTOR
            #print("CS1: ", color(CS1))
        # If right sensor crosses line, skew left
        #if (color(CS2) == line_color) and (skew < 100):
            #skew = skew + SKEW_FACTOR
            #print("CS2: ", color(CS2))
        #if (GS.get_dps_measure() < initial_angle) and (skew < 100):
        #    skew = skew - SKEW_FACTOR
        #    print("correcting right: ", GS.get_dps_measure(), " skew: ", skew)
        #if (GS.get_dps_measure() > initial_angle) and (skew > 0):
        #    skew = skew + SKEW_FACTOR
        #    print("correcting left: ", GS.get_dps_measure(), " skew: ", skew)

def turn_left():
    DURATION = 0
    rotate(0, DURATION)
    position = (position + 1) % 4
    
def turn_right():
    DURATION = 0
    rotate(1, DURATION)
    position = (position + 3) % 4

def spin_carousel():
    pass

# MAIN PROGRAM
straight(0,1)
