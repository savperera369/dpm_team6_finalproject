#!/usr/bin/env bash

# This script installs the required libraries on the brick.
# Run this on the robot by double-clicking and selecting "Run in terminal"

python3 -m pip install lib/simpleaudio-1.0.4-cp39-cp39-linux_armv7l.whl
