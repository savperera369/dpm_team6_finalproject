import math
import time
from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor

print("Initializing sensors and motors...")
CM = Motor("A")
wait_ready_sensors()
print("Sensors and motors initialized.")

CM.set_dps(-100)
time.sleep(1)
CM.set_power(0)
time.sleep(1)
CM.set_dps(100)
time.sleep(1)
CM.set_power(0)

# CM.set_dps(100)
# time.sleep(1.2)
# CM.set_power(0)