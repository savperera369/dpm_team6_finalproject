from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor, EV3GyroSensor

CS1 = EV3ColorSensor(1)
CS2 = EV3ColorSensor(2)   # has sticker
wait_ready_sensors()

while(1):
    pass