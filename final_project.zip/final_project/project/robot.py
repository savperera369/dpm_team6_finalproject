print("Beginning startup...")

import time
import math
from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor

# GLOBAL VARIABLES

enabled = True
job_list = {(0,0,"A"),(0,0,"A"),(0,0,"A")}
RED = (43.5, 9.3, 7.6)
GREEN = (5.0, 19.7, 10.5)
BLUE = (14.8, 11.9, 15.3)
BROWN = (45.9, 30.1, 20.7)
RED_ERROR = 7
GREEN_ERROR = 5
BLUE_ERROR = 8
BROWN_ERROR = 10
position = (0, 0, 0)

# INITIALIZE SENSORS AND MOTORS
print("Initializing sensors and motors...")
#CS1 = EV3ColorSensor(1)
#CS2 = EV3ColorSensor(2)
LM = Motor("C")
RM = Motor("D")
wait_ready_sensors()
print("Sensors and motors initialized.")

# NAVIGATION FUNCTIONS

def color_distance(raw_value1, raw_value2):
    dR = raw_value1[0] - raw_value2[0]
    dG = raw_value1[1] - raw_value2[1]
    dB = raw_value1[2] - raw_value2[2]
    return math.sqrt((dR**2)+(dG**2)+(dB**2))

# Returns NONE if: (1) black, (2) between colors, (3) not sure
def color(sensor_name):
    raw_value = sensor_name.get_raw_value()
    if color_distance(raw_value, RED) <= RED_ERROR:
        return "RED"
    elif color_distance(raw_value, GREEN) <= GREEN_ERROR:
        return "GREEN"
    elif color_distance(raw_value, BLUE) <= BLUE_ERROR:
        return "BLUE"
    elif color_distance(raw_value,BROWN) <= BROWN_ERROR:
        return "BROWN"
    else:
        return "NONE"

def stop():
    LM.set_power(0)
    RM.set_power(0)

def forward(t):    # Forward for t seconds
    POWER = 50     # Base power
    SKEW_FACTOR = 5     # How much to adjust skew when crossing line
    # How skewed power distribution is towards left motor
    # 50 = balanced, 100 = all left motor, 0 = all right motor
    skew = 50
    # If facing +x or -x direction, follows blue lines
    if (position[2] == 0) or (position[2] == 2):
        line_color = "BLUE"
    # If facing +y or -y direction, follow red lines
    if (position[2] == 1) or (position[2] == 3):
        line_color = "RED"
    start_time = time.time()
    while (time.time() - start_time) < t:
        LM.set_power(power * (skew / 100))
        RM.set_power(power * ((100 - skew) / 100))
        # If left sensor crosses line, skew right
        if (color(CS1) = line_color) and (skew > 0):
            skew = skew - SKEW_FACTOR
        # If right sensor crosses line, skew left
        if (color(CS2) = line_color) and (skew < 100):
            skew = skew + SKEW_FACTOR
    stop()

def reverse(d):
    print("Reverse", end="")
    
def left():
    print("left")
    
def right():
    print("right")

def spin_carousel():
    print("hi")

# MAIN PROGRAM
forward(4)