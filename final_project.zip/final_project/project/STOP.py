import time
import math
from utils.brick import Motor, wait_ready_sensors, EV3ColorSensor

LM = Motor("D")
RM = Motor("C")
wait_ready_sensors()
print("stopping")
LM.set_power(0)
RM.set_power(0)