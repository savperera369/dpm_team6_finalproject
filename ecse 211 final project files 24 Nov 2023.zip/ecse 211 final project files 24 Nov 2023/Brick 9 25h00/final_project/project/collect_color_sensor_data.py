#!/usr/bin/env python3

"""
This test is used to collect data from the color sensor.
It must be run on the robot.
"""

# Add your imports here, if any
from utils.brick import EV3ColorSensor, wait_ready_sensors, TouchSensor
import csv
import time


COLOR_SENSOR_DATA_FILE = "../data_analysis/color_sensor_final.csv"

# complete this based on your hardware setup
COLOR_SENSOR = EV3ColorSensor(2)
#COLOR_SENSOR = EV3ColorSensor(2)
# TOUCH_SENSOR = TouchSensor(1)

wait_ready_sensors(True) # Input True to see what the robot is trying to initialize! False to be silent.


def collect_color_sensor_data():
    "Collect color sensor data."
    try:
        already_pressed = False
        while True:
#             if TOUCH_SENSOR.is_pressed():
#                 if not already_pressed:
            color_data = COLOR_SENSOR.get_raw_value()
            output_file = open(COLOR_SENSOR_DATA_FILE, 'a', newline = '')
            writer = csv.writer(output_file)
            writer.writerow(color_data)
            print(color_data)
            already_pressed = True
            output_file.close()
            time.sleep(.25)
#             if not TOUCH_SENSOR.is_pressed():
#                 already_pressed = False
        
    except BaseException:  # capture all exceptions including KeyboardInterrupt (Ctrl-C)
        exit()

if __name__ == "__main__":
    #output_file = open(COLOR_SENSOR_DATA_FILE, 'w', newline = '')
    #writer = csv.writer(output_file)
    #writer.writerow([1, 2, 3])
    #output_file.close()
    
    collect_color_sensor_data()
